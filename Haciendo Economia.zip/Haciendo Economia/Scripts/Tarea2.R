# Cargar las librerías necesarias
library(haven)
library(dplyr)
library(ggplot2)
library(kableExtra) 
library(gridExtra)   
library(ggthemes)
library(tidyr)
library(stringr)
library(readxl)

# Leer el archivo de tenderos
BaseTenderos <- read_dta("C:/Users/crist/Downloads/TenderosFU03_BLandFUmerged_pub.dta")

# Agrupar por municipio y actividades económicas y luego sumar 'ventas'
Base_Agrupados <- BaseTenderos %>%
  group_by(Munic_Dept) %>%
  summarise(
    AG1 = sum(actG1, na.rm = TRUE),
    AG2 = sum(actG2, na.rm = TRUE),
    AG3 = sum(actG3, na.rm = TRUE),
    AG4 = sum(actG4, na.rm = TRUE),
    AG5 = sum(actG5, na.rm = TRUE),
    AG6 = sum(actG6, na.rm = TRUE),
    AG7 = sum(actG7, na.rm = TRUE),
    AG8 = sum(actG8, na.rm = TRUE),
    AG9 = sum(actG9, na.rm = TRUE),
    AG10 = sum(actG10, na.rm = TRUE),
    AG11 = sum(actG11, na.rm = TRUE),
    total = n()
  )
View(Base_Agrupados)

# Cargar el archivo de población
Data_Poblacion <- read_excel("C:/Users/crist/OneDrive/Escritorio/7S/Data_Poblacion.xlsx")

# Verificar nombres de columnas para asegurarnos de que existen
print("Nombres de columnas en Data_Poblacion:")
print(colnames(Data_Poblacion))

# Filtrar solo los datos del año 2022 y las categorías necesarias
Data_Poblacion_Filtrada <- Data_Poblacion %>%
  filter(Indicador %in% c("Población total de hombres", "Población total de mujeres") & Año == 2022) %>%
  select(`Código Entidad`, Indicador, `Dato Numérico`, Entidad)

# Convertir Código Entidad a numérico para que coincida con Base_Agrupados
Data_Poblacion_Filtrada <- Data_Poblacion_Filtrada %>%
  mutate(`Código Entidad` = as.numeric(`Código Entidad`))

# Convertir los datos de población de filas a columnas
Data_Poblacion_Wide <- Data_Poblacion_Filtrada %>%
  pivot_wider(names_from = Indicador, values_from = `Dato Numérico`)

# Verificar nombres de columnas después de pivot_wider
print("Nombres de columnas después de pivot_wider:")
print(colnames(Data_Poblacion_Wide))

# Unir con la base de tenderos asegurando que las claves sean del mismo tipo
Base_Agrupados <- Base_Agrupados %>%
  mutate(Munic_Dept = as.numeric(Munic_Dept))

Base_Merge <- Base_Agrupados %>%
  left_join(Data_Poblacion_Wide, by = c("Munic_Dept" = "Código Entidad"))

# Verificar nombres de columnas después del merge
print("Nombres de columnas después del left_join:")
print(colnames(Base_Merge))

# Limpiar los valores de Pob_Hombres y Pob_Mujeres asegurándonos de usar los nombres correctos
Base_Merge <- Base_Merge %>%
  rename(
    Pob_Hombres = `Población total de hombres`,
    Pob_Mujeres = `Población total de mujeres`
  ) %>%
  mutate(
    Pob_Hombres = as.numeric(gsub("[^0-9]", "", as.character(Pob_Hombres))),
    Pob_Mujeres = as.numeric(gsub("[^0-9]", "", as.character(Pob_Mujeres))),
    Pob_Total = ifelse(is.na(Pob_Hombres) | is.na(Pob_Mujeres), NA, Pob_Hombres + Pob_Mujeres)
  )

# Verificar si Pob_Total existe y tiene valores
print("Resumen de Pob_Total:")
print(summary(Base_Merge$Pob_Total))

# Mostrar la tabla resultante
View(Base_Merge)

#3
#Crear una nueva tabla internet_negocios
base_internet=BaseTenderos %>% 
  filter(uso_internet==1)

#Agrupar por actividad
base_internet <- base_internet %>%
  group_by(Munic_Dept) %>%
  summarise(
    AG1 = sum(actG1, na.rm = TRUE),
    AG2 = sum(actG2, na.rm = TRUE),
    AG3 = sum(actG3, na.rm = TRUE),
    AG4 = sum(actG4, na.rm = TRUE),
    AG5 = sum(actG5, na.rm = TRUE),
    AG6 = sum(actG6, na.rm = TRUE),
    AG7 = sum(actG7, na.rm = TRUE),
    AG8 = sum(actG8, na.rm = TRUE),
    AG9 = sum(actG9, na.rm = TRUE),
    AG10 = sum(actG10, na.rm = TRUE),
    AG11 = sum(actG11, na.rm = TRUE),
    total = n()
  )

# Asegurar que ambas bases tengan los mismos municipios antes de la división
Base_Agrupados <- Base_Agrupados %>% arrange(Munic_Dept)
base_internet <- base_internet %>% arrange(Munic_Dept)

# Crear la tabla de proporciones dividiendo base_internet entre Base_Agrupados
proporciones_internet <- base_internet

# Reemplazar la primera columna con la del total de municipios
proporciones_internet[,-1] <- round((base_internet[,-1] / Base_Agrupados[,-1]) * 100, 2)

# Convertir valores a formato de porcentaje con "%"
proporciones_internet[,-1] <- apply(proporciones_internet[,-1], 2, function(x) paste0(x, "%"))

# Mostrar la tabla resultante
View(proporciones_internet)

