# Cargar las librerías necesarias
library(haven)
library(dplyr)
library(ggplot2)
library(kableExtra) 
library(gridExtra)   
library(ggthemes)    

# Leer el archivo
TenderosFU03_BLandFUmerged_pub <- read_dta("C:/Users/crist/Downloads/TenderosFU03_BLandFUmerged_pub.dta")

# Filtrar los datos para eliminar donde Solic_Credito == 3 (No sabe no hace gracia en estudio)
Tenderos_filtrado <- TenderosFU03_BLandFUmerged_pub %>% 
  filter(Solic_Credito != 3)

# Tabla de frecuencias después de la filtración
tabla_frecuencia <- as.data.frame(table(Tenderos_filtrado$Solic_Credito))

# Mostrar tabla
kable(tabla_frecuencia, caption = "Frecuencia Solicitud Creditos",
      col.names = c("Solicitud", "Frecuencia")) %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), full_width = FALSE)

# Crear la tabla cruzada
tabla_crosstab <- as.data.frame(table(Tenderos_filtrado$Solic_Credito, Tenderos_filtrado$actividad1))

# Ajustar la tabla para que sea más compacta
kable(tabla_crosstab, caption = "Solicitud de Crédito vs Actividad",
      col.names = c("Solicitud", "Actividad", "Frecuencia")) %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), 
                font_size = 12, full_width = FALSE) %>%  # Reducimos el tamaño de fuente
  column_spec(1, width = "5em") %>%  # Ajustamos ancho de columnas
  column_spec(2, width = "5em") %>%
  column_spec(3, width = "5em")

# Gráfico de densidad 
densidad_plot <- ggplot(Tenderos_filtrado, aes(x=Solic_Credito)) + 
  geom_density(fill="royalblue", alpha=0.6, color="black") + 
  geom_vline(aes(xintercept=mean(Solic_Credito, na.rm=TRUE)),
             color="red", linetype="dashed", size=1) +
  labs(title="Distribución de Creditos", 
       x="Credito", 
       y="Densidad") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face="bold", hjust = 0.5),
        axis.title = element_text(face="bold"),
        panel.grid.major = element_line(color = "gray85"))

# Histograma
histograma_plot <- ggplot(Tenderos_filtrado, aes(x=Solic_Credito)) +
  geom_bar(fill="coral", color="black", alpha=0.7) +
  labs(title="Frecuencia de Solicitud Credito", x="Solicitud", y="Frecuencia") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face="bold", hjust = 0.5),
        axis.title = element_text(face="bold"),
        panel.grid.major = element_line(color = "gray85"))

# Mostrar gráficos juntos
grid.arrange(densidad_plot, histograma_plot, nrow = 1)

# Gráfico de barras segmentado por actividad economica
barplot_sector <- ggplot(Tenderos_filtrado, aes(x=as.factor(actividad1), fill=as.factor(Solic_Credito))) +
  geom_bar(position="dodge", color="black", alpha=0.8) +  # `position="dodge"` pone las barras lado a lado
  scale_fill_manual(values=c("#1f78b4", "#e31a1c"), labels=c("Solicitó (1)", "No Solicitó (2)")) + 
  labs(title="Solicitud de Crédito por Actividad",
       x="Actividad1",
       y="Frecuencia",
       fill="Solic_Credito") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face="bold", hjust = 0.5),
        axis.title = element_text(face="bold"),
        legend.title = element_blank(),
        panel.grid.major = element_line(color = "gray85"))

# Mostrar el barplot
print(barplot_sector)
